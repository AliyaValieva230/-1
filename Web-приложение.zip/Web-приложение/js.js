// Общее поведение для всех страниц

// Определяем текущий URL для разветвления логики
const url = window.location.pathname;

// Получение элементов для навигации
const addBtn = document.getElementById('addBtn');
const eventsContainer = document.getElementById('events');

const filterCategory = document.getElementById('filterCategory');
const sortDate = document.getElementById('sortDate');

if (url.endsWith('index.html') || url.endsWith('/')) {
  // Главная страница
  initIndexPage();
} else if (url.endsWith('add-page.html')) {
  // Страница добавления
  initAddPage();
} else if (url.endsWith('edit-page.html')) {
  // Страница редактирования
  initEditPage();
}

function loadEvents() {
  const data = localStorage.getItem('events');
  return data ? JSON.parse(data) : [];
}

function saveEvents(events) {
  localStorage.setItem('events', JSON.stringify(events));
}

// -------------- Главная страница ----------------
function initIndexPage() {
  // Кнопка "Добавить новое событие"
  document.getElementById('addBtn').addEventListener('click', () => {
    window.location.href = 'add-page.html';
  });

  // Фильтр и сортировка
  filterCategory.addEventListener('change', renderEvents);
  sortDate.addEventListener('change', renderEvents);

  // Начальная отрисовка
  renderEvents();

  function renderEvents() {
    eventsContainer.innerHTML = '';
    let events = loadEvents();

    // Фильтрация
    const categoryFilter = document.getElementById('filterCategory').value;
    if (categoryFilter) {
      events = events.filter(ev => ev.category === categoryFilter);
    }

    // Сортировка
    const sortType = document.getElementById('sortDate').value;
    events.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      if (sortType === 'nearest') {
        return dateA - dateB;
      } else {
        return dateB - dateA;
      }
    });

    // Создаем карточки
    events.forEach(ev => {
      const card = document.createElement('div');
      card.className = 'card';
      card.dataset.id = ev.id;
      card.innerHTML = `
        <h3>${ev.title}</h3>
        <p>Дата: ${ev.date}</p>
        <p>Категория: ${ev.category}</p>
      `;
      // Перейти к редактированию при клике
      card.addEventListener('click', () => {
        localStorage.setItem('currentEventId', ev.id); // для передачи на страницу редактирования
        window.location.href = 'edit-page.html';
      });
      eventsContainer.appendChild(card);
    });
  }
}

// -------------- Страница добавления ----------------
function initAddPage() {
  const form = document.getElementById('eventForm');
  const cancelBtn = document.getElementById('cancelBtn');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const newEvent = {
      id: Date.now().toString(),
      title: document.getElementById('title').value,
      date: document.getElementById('date').value,
      category: document.getElementById('category').value,
      description: document.getElementById('description').value,
    };
    const events = loadEvents();
    events.push(newEvent);
    saveEvents(events);
    window.location.href = 'index.html';
  });

  cancelBtn.addEventListener('click', () => {
    window.location.href = 'index.html';
  });
}

// -------------- Страница редактирования ----------------
function initEditPage() {
  const id = localStorage.getItem('currentEventId') || '';
  const events = loadEvents();
  const event = events.find(e => e.id === id);
  if (!event) {
    alert('Событие не найдено');
    window.location.href = 'index.html';
    return;
  }

  // Заполняем поля
  document.getElementById('editId').value = event.id;
  document.getElementById('editTitle').value = event.title;
  document.getElementById('editDate').value = event.date;
  document.getElementById('editCategory').value = event.category;
  document.getElementById('editDescription').value = event.description;

  // Обработчик формы
  document.getElementById('editForm').addEventListener('submit', (e) => {
    e.preventDefault();
    event.title = document.getElementById('editTitle').value;
    event.date = document.getElementById('editDate').value;
    event.category = document.getElementById('editCategory').value;
    event.description = document.getElementById('editDescription').value;

    // Обновляем в localStorage
    saveEvents(events);
    window.location.href = 'index.html';
  });

  // Удаление
  document.getElementById('deleteBtn').addEventListener('click', () => {
    const index = events.findIndex(e => e.id === id);
    if (index > -1) {
      events.splice(index, 1);
      saveEvents(events);
    }
    window.location.href = 'index.html';
  });

  // Отмена
  document.getElementById('cancelEditBtn').addEventListener('click', () => {
    window.location.href = 'index.html';
  });
}
