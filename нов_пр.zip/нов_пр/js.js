const themeToggle = document.getElementById("themeToggle");
let darkMode = false;

themeToggle.addEventListener("click", () => {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-theme", darkMode);
    themeToggle.textContent = darkMode ? "Сменить на светлую тему" : "Сменить на тёмную тему";
});
